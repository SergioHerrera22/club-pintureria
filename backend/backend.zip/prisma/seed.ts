import { PrismaClient, UserRole, RuleType, PrizeStatus } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');
  
  const passwordHash = await bcrypt.hash('123456', 12);
  
  const admin = await prisma.user.upsert({
    where: { email: 'admin@clubpintureria.com' },
    update: {},
    create: {
      email: 'admin@clubpintureria.com',
      passwordHash,
      firstName: 'Admin',
      lastName: 'Sistema',
      dni: '00000000',
      role: UserRole.ADMIN,
    },
  });
  
  const cajera = await prisma.user.upsert({
    where: { email: 'cajera@clubpintureria.com' },
    update: {},
    create: {
      email: 'cajera@clubpintureria.com',
      passwordHash,
      firstName: 'María',
      lastName: 'González',
      dni: '11111111',
      role: UserRole.CAJERA,
    },
  });
  
  const cliente1 = await prisma.user.upsert({
    where: { dni: '20123456' },
    update: {},
    create: {
      email: 'juan.perez@email.com',
      passwordHash,
      firstName: 'Juan',
      lastName: 'Pérez',
      dni: '20123456',
      phone: '1155551234',
      birthDate: new Date('1985-05-15'),
      role: UserRole.CLIENTE,
    },
  });
  
  const cliente2 = await prisma.user.upsert({
    where: { dni: '27654321' },
    update: {},
    create: {
      email: 'maria.lopez@email.com',
      passwordHash,
      firstName: 'María',
      lastName: 'López',
      dni: '27654321',
      phone: '1144445678',
      birthDate: new Date('1990-08-22'),
      role: UserRole.CLIENTE,
    },
  });
  
  // Create default branch
  await prisma.branch.upsert({
    where: { code: 'SUC001' },
    update: {},
    create: {
      name: 'Sucursal Central',
      code: 'SUC001',
      address: 'Av. Corrientes 1234, CABA',
      phone: '11 4444-5555',
      email: 'central@clubpintureria.com',
      isActive: true,
    },
  });
  
  await prisma.clientProfile.upsert({
    where: { userId: cliente1.id },
    update: {},
    create: { userId: cliente1.id, currentPoints: 1250, totalPointsEarned: 1250, tier: 'SILVER' },
  });
  
  await prisma.clientProfile.upsert({
    where: { userId: cliente2.id },
    update: {},
    create: { userId: cliente2.id, currentPoints: 340, totalPointsEarned: 340, tier: 'BRONZE' },
  });
  
  const products = [
    { code: 'PNT-001', name: 'Barniz Acrílico 2K Brillante 1L', category: 'Barnices', brand: 'PPG', unitPrice: 45000 },
    { code: 'PNT-002', name: 'Barniz Acrílico 2K Mate 1L', category: 'Barnices', brand: 'PPG', unitPrice: 43000 },
    { code: 'PNT-003', name: 'Base Agua Color Rojo Ferrari 500ml', category: 'Bases Agua', brand: 'Glasurit', unitPrice: 28000 },
    { code: 'PNT-004', name: 'Base Agua Color Negro Perla 500ml', category: 'Bases Agua', brand: 'Glasurit', unitPrice: 32000 },
    { code: 'PNT-005', name: 'Catalizador Rápido 1L', category: 'Catalizadores', brand: 'PPG', unitPrice: 18000 },
    { code: 'PNT-006', name: 'Catalizador Estándar 1L', category: 'Catalizadores', brand: 'PPG', unitPrice: 15000 },
    { code: 'PNT-007', name: 'Diluyente Universal 5L', category: 'Diluyentes', brand: 'Genérico', unitPrice: 12000 },
    { code: 'PNT-008', name: 'Masa Poliéster 2K 1kg', category: 'Masillas', brand: 'U-POL', unitPrice: 9500 },
    { code: 'PNT-009', name: 'Aparejo Epóxico Gris 1L', category: 'Aparejos', brand: 'Glasurit', unitPrice: 22000 },
    { code: 'PNT-010', name: 'Limpiador Antiestático 1L', category: 'Limpieza', brand: 'PPG', unitPrice: 8500 },
  ];
  
  for (const p of products) {
    await prisma.product.upsert({
      where: { code: p.code },
      update: {},
      create: p,
    });
  }
  
  const rule1 = await prisma.pointRule.upsert({
    where: { id: 'rule-base' },
    update: {},
    create: {
      id: 'rule-base',
      name: 'Regla Base: 1 punto por $100',
      description: 'Otorga 1 punto por cada $100 de compra',
      type: RuleType.POR_MONTO,
      config: { puntosPorMonto: 0.01, montoMinimo: 1000 },
      priority: 10,
    },
  });
  
  const premiumProducts = await prisma.product.findMany({
    where: { category: { in: ['Barnices', 'Bases Agua'] } },
    select: { id: true },
  });
  
  await prisma.pointRule.upsert({
    where: { id: 'rule-premium' },
    update: {},
    create: {
      id: 'rule-premium',
      name: 'Bonus Productos Premium 2x',
      description: 'Doble puntos en barnices y bases agua',
      type: RuleType.POR_CATEGORIA,
      config: { categorias: ['Barnices', 'Bases Agua'], multiplicador: 0.01 },
      priority: 20,
    },
  });
  
  await prisma.pointRule.upsert({
    where: { id: 'rule-first' },
    update: {},
    create: {
      id: 'rule-first',
      name: 'Bienvenida: 500 puntos primera compra',
      description: 'Bonus de bienvenida para nuevos clientes',
      type: RuleType.PRIMERA_COMPRA,
      config: { bonusPrimeraCompra: 500 },
      priority: 30,
    },
  });
  
  await prisma.pointRule.upsert({
    where: { id: 'rule-birthday' },
    update: {},
    create: {
      id: 'rule-birthday',
      name: 'Regalo Cumpleaños: 200 puntos',
      description: 'Bonus en el mes de cumpleaños',
      type: RuleType.CUMPLEANOS,
      config: { bonusCumpleanos: 200 },
      priority: 25,
    },
  });
  
  const prizes = [
    { code: 'PRZ-001', name: 'Descuento $5.000', description: 'Vale de descuento en próxima compra', pointsCost: 500, stock: 100, category: 'Descuentos' },
    { code: 'PRZ-002', name: 'Descuento $10.000', description: 'Vale de descuento en próxima compra', pointsCost: 900, stock: 50, category: 'Descuentos' },
    { code: 'PRZ-003', name: 'Descuento $25.000', description: 'Vale de descuento en próxima compra', pointsCost: 2000, stock: 20, category: 'Descuentos' },
    { code: 'PRZ-004', name: 'Kit Limpieza Profesional', description: 'Incluye limpiador, paños y guantes', pointsCost: 3000, stock: 10, category: 'Productos' },
    { code: 'PRZ-005', name: 'Pistola Pintura HVLP', description: 'Pistola profesional para repintado', pointsCost: 15000, stock: 3, category: 'Herramientas' },
    { code: 'PRZ-006', name: 'Curso Capacitación PPG', description: 'Curso online certificado 4 horas', pointsCost: 8000, stock: 5, category: 'Experiencias' },
  ];
  
  for (const p of prizes) {
    await prisma.prize.upsert({
      where: { code: p.code },
      update: {},
      create: p,
    });
  }
  
  console.log('✅ Database seeded successfully!');
  console.log('👤 Admin: admin@clubpintureria.com / 123456');
  console.log('👤 Cajera: cajera@clubpintureria.com / 123456');
  console.log('👤 Cliente 1: 20123456 / 123456');
  console.log('👤 Cliente 2: 27654321 / 123456');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });