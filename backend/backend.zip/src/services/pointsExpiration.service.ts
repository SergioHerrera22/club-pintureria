import { prisma } from '../config/prisma';
import { TransactionType } from '@prisma/client';
import { emailService } from './email.service';
import { whatsappService } from './whatsapp.service';

interface ExpirationResult {
  expiredCount: number;
  notifiedCount: number;
  errors: string[];
}

export class PointsExpirationService {
  static async expirePoints(): Promise<ExpirationResult> {
    const result: ExpirationResult = { expiredCount: 0, notifiedCount: 0, errors: [] };
    
    try {
      const now = new Date();
      
      // Get all active tiers with expiry days configured
      const tiersWithExpiry = await prisma.tierConfig.findMany({
        where: {
          isActive: true,
          pointsExpiryDays: { not: null },
        },
      });
      
      if (tiersWithExpiry.length === 0) {
        return result;
      }
      
      // Get all clients with their tier and last activity
      const clients = await prisma.user.findMany({
        where: {
          role: 'CLIENTE',
          isActive: true,
          clientProfile: {
            currentPoints: { gt: 0 },
          },
        },
        include: {
          clientProfile: true,
          transactions: {
            where: { type: { in: ['COMPRA', 'CANJE'] } },
            orderBy: { createdAt: 'desc' },
            take: 1,
          },
        },
      });
      
      for (const user of clients) {
        if (!user.clientProfile) continue;
        
        const tier = tiersWithExpiry.find(t => t.name === user.clientProfile?.tier);
        if (!tier || !tier.pointsExpiryDays) continue;
        
        const expiryDays = tier.pointsExpiryDays;
        const lastActivity = user.transactions[0]?.createdAt || user.clientProfile.lastPurchaseAt || user.createdAt;
        const daysSinceActivity = Math.floor((now.getTime() - new Date(lastActivity).getTime()) / (1000 * 60 * 60 * 24));
        
        if (daysSinceActivity >= expiryDays) {
          // Expire points
          try {
            await this.expireClientPoints(user.id, user.clientProfile.currentPoints, expiryDays);
            result.expiredCount++;
          } catch (err) {
            result.errors.push(`Error expirando puntos de ${user.dni}: ${err}`);
          }
        } else if (daysSinceActivity >= expiryDays - 7 && daysSinceActivity < expiryDays) {
          // Notify 7 days before expiry
          try {
            await this.notifyExpiryWarning(user, tier, expiryDays - daysSinceActivity);
            result.notifiedCount++;
          } catch (err) {
            result.errors.push(`Error notificando expiración a ${user.dni}: ${err}`);
          }
        }
      }
    } catch (error) {
      result.errors.push(`Error general: ${error}`);
    }
    
    return result;
  }
  
  private static async expireClientPoints(userId: string, points: number, expiryDays: number): Promise<void> {
    await prisma.$transaction(async (tx) => {
      // Create expiration transaction
      await tx.transaction.create({
        data: {
          userId,
          type: TransactionType.VENCIMIENTO,
          subtotal: 0,
          total: 0,
          pointsEarned: -points,
          pointsBalance: 0,
          description: `Vencimiento por inactividad de ${expiryDays} días`,
        },
      });
      
      // Update client profile
      await tx.clientProfile.update({
        where: { userId },
        data: {
          currentPoints: 0,
        },
      });
      
      // Create notification
      await tx.notification.create({
        data: {
          userId,
          type: 'POINTS_EXPIRED',
          title: 'Puntos vencidos',
          message: `Tus ${points} puntos han vencido por inactividad de ${expiryDays} días`,
          metadata: { points, expiryDays },
        },
      });
    });
  }
  
  private static async notifyExpiryWarning(user: any, tier: any, daysLeft: number): Promise<void> {
    const message = `Tus ${user.clientProfile?.currentPoints || 0} puntos vencerán en ${daysLeft} días por inactividad. Realiza una compra para mantenerlos activos.`;
    
    // Create in-app notification
    await prisma.notification.create({
      data: {
        userId: user.id,
        type: 'POINTS_EXPIRING_SOON',
        title: 'Puntos por vencer',
        message,
        metadata: { daysLeft, points: user.clientProfile?.currentPoints },
      },
    });
    
    // Send email if available
    if (user.email) {
      await emailService.sendPointsExpiringEmail(user.email, user.firstName, user.clientProfile?.currentPoints || 0, daysLeft);
    }
    
    // Send WhatsApp if available
    if (user.phone) {
      const whatsappBody = `⚠️ *Aviso Club Pinturería*\n\nTus *${user.clientProfile?.currentPoints || 0} puntos* vencerán en *${daysLeft} días* por inactividad.\n\nRealizá una compra para mantenerlos activos.\n\nClub Pinturería 🎨`;
      await whatsappService.sendMessage(user.phone, whatsappBody);
    }
  }
  
  // Manual trigger for admin
  static async expirePointsForClient(dni: string): Promise<{ success: boolean; message: string }> {
    const user = await prisma.user.findUnique({
      where: { dni },
      include: { clientProfile: true },
    });
    
    if (!user || !user.clientProfile) {
      return { success: false, message: 'Cliente no encontrado' };
    }
    
    const tier = await prisma.tierConfig.findUnique({
      where: { name: user.clientProfile.tier },
    });
    
    if (!tier || !tier.pointsExpiryDays) {
      return { success: false, message: 'El tier del cliente no tiene vencimiento configurado' };
    }
    
    await this.expireClientPoints(user.id, user.clientProfile.currentPoints, tier.pointsExpiryDays);
    
    return { success: true, message: `Expirados ${user.clientProfile.currentPoints} puntos` };
  }
}