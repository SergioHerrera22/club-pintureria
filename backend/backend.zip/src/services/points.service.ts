import { prisma } from '../config/prisma';
import { RuleType, TransactionType, Prisma } from '@prisma/client';
import { PromotionService } from './promotion.service';

interface RuleConfig {
  puntosPorMonto?: number;
  montoMinimo?: number;
  multiplicador?: number;
  categorias?: string[];
  productosIds?: string[];
  bonusPrimeraCompra?: number;
  bonusCumpleanos?: number;
  rangos?: Array<{ min: number; max: number; puntos: number }>;
}

interface TierConfig {
  name: string;
  label: string;
  pointsMultiplier: number;
  pointsExpiryDays: number | null;
  birthdayBonusPoints: number;
}

interface PromotionContext {
  clientTier: string;
  items: Array<{ productId: string; quantity: number; unitPrice: number; lineTotal: number }>;
  subtotal: number;
  categoryIds: string[];
  brandIds: string[];
  productIds: string[];
}

export class PointsService {
  static async calculatePoints(
    userId: string,
    items: Array<{ productId: string; quantity: number; unitPrice: number; lineTotal: number }>,
    subtotal: number
  ): Promise<{ totalPoints: number; breakdown: Array<{ rule: string; points: number }> }> {
    console.log('[PointsService] calculatePoints called:', { userId, subtotal, itemsCount: items.length });
    
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { clientProfile: true },
    });
    
    if (!user || !user.clientProfile) {
      throw new Error('Usuario o perfil no encontrado');
    }
    
    console.log('[PointsService] User found:', { 
      userId: user.id, 
      tier: user.clientProfile.tier, 
      totalPointsEarned: user.clientProfile.totalPointsEarned,
      isFirstPurchase: user.clientProfile.totalPointsEarned === 0
    });
    
    const tierConfig = await this.getTierConfig(user.clientProfile.tier);
    const tierMultiplier = tierConfig?.pointsMultiplier || 1.0;
    
    console.log('[PointsService] Tier config:', { tierConfig, tierMultiplier });
    
    const isFirstPurchase = user.clientProfile.totalPointsEarned === 0;
    const isBirthday = user.birthDate && this.isBirthday(user.birthDate);
    
    const now = new Date();
    const activeRules = await prisma.pointRule.findMany({
      where: {
        isActive: true,
        AND: [
          {
            OR: [
              { validFrom: null },
              { validFrom: { lte: now } },
            ],
          },
          {
            OR: [
              { validTo: null },
              { validTo: { gte: now } },
            ],
          },
        ],
      },
      orderBy: { priority: 'desc' },
      include: { products: true },
    });
    
    console.log('[PointsService] Active rules found:', activeRules.length);
    activeRules.forEach(r => console.log('[PointsService] Rule:', { 
      id: r.id, 
      name: r.name, 
      type: r.type, 
      isActive: r.isActive, 
      config: r.config,
      validFrom: r.validFrom,
      validTo: r.validTo
    }));
    
    let totalPoints = 0;
    const breakdown: any[] = [];
    
    for (const rule of activeRules) {
      const config = rule.config as unknown as RuleConfig;
      let rulePoints = 0;
      
      console.log('[PointsService] Processing rule:', { ruleName: rule.name, ruleType: rule.type, config });
      
      switch (rule.type) {
        case RuleType.POR_MONTO:
          rulePoints = this.calculatePorMonto(subtotal, config);
          break;
        case RuleType.POR_PRODUCTO:
          rulePoints = this.calculatePorProducto(items, config);
          break;
        case RuleType.POR_CATEGORIA:
          rulePoints = await this.calculatePorCategoria(items, config);
          break;
        case RuleType.PRIMERA_COMPRA:
          if (isFirstPurchase && config.bonusPrimeraCompra) {
            rulePoints = config.bonusPrimeraCompra;
          }
          break;
        case RuleType.CUMPLEANOS:
          if (isBirthday) {
            rulePoints = tierConfig?.birthdayBonusPoints || config.bonusCumpleanos || 0;
          }
          break;
        case RuleType.RANGO_MONTO:
          rulePoints = this.calculatePorRango(subtotal, config);
          break;
      }
      
      console.log('[PointsService] Rule points calculated:', { ruleName: rule.name, rulePoints });
      
      if (rulePoints > 0) {
        const finalPoints = Math.floor(rulePoints * tierMultiplier);
        totalPoints += finalPoints;
        
        // Detailed breakdown entry
        const detailEntry = {
          rule: rule.name,
          type: rule.type,
          basePoints: rulePoints,
          tierMultiplier: tierMultiplier,
          finalPoints: finalPoints,
          description: PointsService.getRuleDescription(rule.type, rulePoints, tierMultiplier, isFirstPurchase, isBirthday || false)
        };
        
        breakdown.push(detailEntry);
        totalPoints += finalPoints;
        console.log('[PointsService] Added points:', { ruleName: rule.name, detailEntry, totalPoints });
      }
    }
    
    console.log('[PointsService] Final result:', { totalPoints, breakdown });
    return { totalPoints, breakdown };
  }

  static async calculatePointsWithPromotions(
    userId: string,
    items: Array<{ productId: string; quantity: number; unitPrice: number; lineTotal: number }>,
    subtotal: number,
    categoryIds: string[] = [],
    brandIds: string[] = [],
    productIds: string[] = []
  ): Promise<{ totalPoints: number; breakdown: any[]; appliedPromotions: Array<{ promotion: any; points: number; discount: number }> }> {
    const baseResult = await this.calculatePoints(userId, items, subtotal);
    
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { clientProfile: true },
    });
    
    if (!user || !user.clientProfile) {
      throw new Error('Usuario o perfil no encontrado');
    }

    const promoContext: PromotionContext = {
      clientTier: user.clientProfile.tier,
      items,
      subtotal,
      categoryIds,
      brandIds,
      productIds,
    };

    const applicablePromotions = await PromotionService.getActivePromotionsForClient(
      promoContext.clientTier,
      promoContext.items,
      promoContext.subtotal,
      promoContext.categoryIds,
      promoContext.brandIds,
      promoContext.productIds
    );

    let additionalPoints = 0;
    const appliedPromotions: Array<{ promotion: any; points: number; discount: number }> = [];

    for (const promo of applicablePromotions) {
      const impact = PromotionService.calculatePromotionImpact(promo.promotion, subtotal, baseResult.totalPoints);
      additionalPoints += impact.points;
      appliedPromotions.push({
        promotion: promo.promotion,
        points: impact.points,
        discount: impact.discount,
      });
    }

    const finalPoints = baseResult.totalPoints + additionalPoints;

    const finalBreakdown: any[] = [...baseResult.breakdown];
    for (const promo of appliedPromotions) {
      if (promo.points > 0) {
        finalBreakdown.push({
          rule: `Promoción: ${promo.promotion.name}`,
          type: 'PROMOCION',
          basePoints: promo.points,
          tierMultiplier: 1,
          finalPoints: promo.points,
          description: `Promoción ${promo.promotion.name}: +${promo.points} pts`
        });
      }
    }

    return {
      totalPoints: finalPoints,
      breakdown: finalBreakdown,
      appliedPromotions,
    };
  }

  private static async getTierConfig(tierName: string): Promise<TierConfig | null> {
    let tier = await prisma.tierConfig.findUnique({
      where: { name: tierName },
    });
    
    // Auto-create default tiers if they don't exist
    if (!tier) {
      console.log(`Tier config "${tierName}" not found, creating defaults...`);
      await PointsService.initializeDefaultTiers();
      tier = await prisma.tierConfig.findUnique({
        where: { name: tierName },
      });
    }
    
    if (!tier) return null;
    return {
      name: tier.name,
      label: tier.label,
      pointsMultiplier: tier.pointsMultiplier,
      pointsExpiryDays: tier.pointsExpiryDays,
      birthdayBonusPoints: tier.birthdayBonusPoints,
    };
  }

  static async initializeDefaultTiers(): Promise<void> {
    const defaultTiers = [
      { name: 'BRONZE', label: 'Bronce', minPoints: 0, maxPoints: 999, color: '#CD7F32', pointsMultiplier: 1.0, pointsExpiryDays: 365, birthdayBonusPoints: 0, isActive: true, sortOrder: 1 },
      { name: 'SILVER', label: 'Plata', minPoints: 1000, maxPoints: 4999, color: '#C0C0C0', pointsMultiplier: 1.25, pointsExpiryDays: 365, birthdayBonusPoints: 100, isActive: true, sortOrder: 2 },
      { name: 'GOLD', label: 'Oro', minPoints: 5000, maxPoints: 19999, color: '#FFD700', pointsMultiplier: 1.5, pointsExpiryDays: 365, birthdayBonusPoints: 250, isActive: true, sortOrder: 3 },
      { name: 'PLATINUM', label: 'Platino', minPoints: 20000, maxPoints: null, color: '#E5E4E2', pointsMultiplier: 2.0, pointsExpiryDays: null, birthdayBonusPoints: 500, isActive: true, sortOrder: 4 },
    ];

    for (const t of defaultTiers) {
      await prisma.tierConfig.upsert({
        where: { name: t.name },
        update: t,
        create: t,
      });
    }
  }
  
  private static getRuleDescription(
    ruleType: string,
    basePoints: number,
    tierMultiplier: number,
    isFirstPurchase: boolean,
    isBirthday: boolean
  ): string {
    const tierNames: Record<number, string> = {
      1: 'Bronce',
      1.25: 'Plata',
      1.5: 'Oro',
      2: 'Platino',
    };
    const tierName = tierNames[tierMultiplier] || `${tierMultiplier}x`;
    
    switch (ruleType) {
      case 'POR_MONTO':
        return `Puntos por compra: ${basePoints} pts (${tierName} x${tierMultiplier})`;
      case 'POR_PRODUCTO':
        return `Puntos por productos específicos: ${basePoints} pts (${tierName} x${tierMultiplier})`;
      case 'POR_CATEGORIA':
        return `Puntos por categoría: ${basePoints} pts (${tierName} x${tierMultiplier})`;
      case 'PRIMERA_COMPRA':
        return `Puntos de bienvenida: ${basePoints} pts (${tierName} x${tierMultiplier})`;
      case 'CUMPLEANOS':
        return `Puntos de cumpleaños: ${basePoints} pts (${tierName} x${tierMultiplier})`;
      case 'RANGO_MONTO':
        return `Puntos por rango de monto: ${basePoints} pts (${tierName} x${tierMultiplier})`;
      default:
        return `${ruleType}: ${basePoints} pts (${tierName} x${tierMultiplier})`;
    }
  }
  
  private static calculatePorMonto(subtotal: number, config: RuleConfig): number {
    const { puntosPorMonto = 0.01, montoMinimo = 0, multiplicador = 1 } = config;
    if (subtotal < montoMinimo) return 0;
    // puntosPorMonto = puntos por peso (ej: 0.01 = 1 punto cada 100 pesos)
    // Fórmula correcta: puntos = subtotal * puntosPorMonto * multiplicador
    return Math.floor(subtotal * puntosPorMonto * multiplicador);
  }
  
  private static calculatePorProducto(
    items: Array<{ productId: string; quantity: number; lineTotal: number }>,
    config: RuleConfig
  ): number {
    const { productosIds = [], multiplicador = 1 } = config;
    if (productosIds.length === 0) return 0;
    
    let points = 0;
    for (const item of items) {
      if (productosIds.includes(item.productId)) {
        points += Math.floor(item.lineTotal * multiplicador);
      }
    }
    return points;
  }
  
  private static async calculatePorCategoria(
    items: Array<{ productId: string; quantity: number; lineTotal: number }>,
    config: RuleConfig
  ): Promise<number> {
    const { categorias = [], multiplicador = 1 } = config;
    if (categorias.length === 0) return 0;
    
    const productIds = items.map(i => i.productId);
    const products = await prisma.product.findMany({
      where: { id: { in: productIds }, category: { in: categorias } },
      select: { id: true },
    });
    
    const categoryProductIds = new Set(products.map(p => p.id));
    let points = 0;
    
    for (const item of items) {
      if (categoryProductIds.has(item.productId)) {
        points += Math.floor(item.lineTotal * multiplicador);
      }
    }
    return points;
  }
  
  private static calculatePorRango(subtotal: number, config: RuleConfig): number {
    const { rangos = [] } = config;
    for (const rango of rangos) {
      if (subtotal >= rango.min && subtotal <= rango.max) {
        return rango.puntos;
      }
    }
    return 0;
  }
  
  private static isBirthday(birthDate: Date): boolean {
    const today = new Date();
    const birth = new Date(birthDate);
    return today.getMonth() === birth.getMonth() && today.getDate() === birth.getDate();
  }
  
  static async addPoints(
    userId: string,
    points: number,
    transactionId: string,
    description?: string
  ): Promise<void> {
    await prisma.$transaction(async (tx) => {
      await tx.clientProfile.update({
        where: { userId },
        data: {
          currentPoints: { increment: points },
          totalPointsEarned: { increment: points },
        },
      });
      
      await tx.notification.create({
        data: {
          userId,
          type: 'POINTS_EARNED',
          title: '¡Puntos ganados!',
          message: `Has ganado ${points} puntos${description ? `: ${description}` : ''}`,
          metadata: { points, transactionId },
        },
      });
    });
  }
  
  static async redeemPoints(
    userId: string,
    points: number,
    redemptionId: string
  ): Promise<void> {
    await prisma.$transaction(async (tx) => {
      const profile = await tx.clientProfile.findUnique({
        where: { userId },
      });
      
      if (!profile || profile.currentPoints < points) {
        throw new Error('Puntos insuficientes');
      }
      
      await tx.clientProfile.update({
        where: { userId },
        data: {
          currentPoints: { decrement: points },
          totalPointsRedeemed: { increment: points },
        },
      });
      
      await tx.notification.create({
        data: {
          userId,
          type: 'POINTS_REDEEMED',
          title: 'Canje realizado',
          message: `Has canjeado ${points} puntos`,
          metadata: { points, redemptionId },
        },
      });
    });
  }
  
  static async adjustPoints(
    userId: string,
    points: number,
    reason: string,
    adminId: string
  ): Promise<void> {
    await prisma.$transaction(async (tx) => {
      const profile = await tx.clientProfile.findUnique({ where: { userId } });
      if (!profile) throw new Error('Perfil no encontrado');
      
      const newBalance = profile.currentPoints + points;
      if (newBalance < 0) throw new Error('El ajuste dejaría puntos negativos');
      
      await tx.clientProfile.update({
        where: { userId },
        data: { currentPoints: newBalance },
      });
      
      await tx.transaction.create({
        data: {
          userId,
          type: TransactionType.AJUSTE_MANUAL,
          subtotal: 0,
          total: 0,
          pointsEarned: points,
          pointsBalance: newBalance,
          description: `Ajuste manual: ${reason}`,
          cashierId: adminId,
        },
      });
      
      await tx.notification.create({
        data: {
          userId,
          type: 'POINTS_ADJUSTED',
          title: 'Ajuste de puntos',
          message: `Tus puntos han sido ajustados: ${points > 0 ? '+' : ''}${points} (${reason})`,
          metadata: { points, reason, adminId },
        },
      });
    });
  }
}