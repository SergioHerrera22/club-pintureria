import { Router } from 'express';
import { z } from 'zod';
import { validate } from '../middleware/validation';
import { PointsExpirationService } from '../services/pointsExpiration.service';
import { emailService } from '../services/email.service';
import { whatsappService } from '../services/whatsapp.service';
import { prisma } from '../config/prisma';
import { authenticate, authorize } from '../middleware/auth';

const router = Router();

// Ejecutar expiración de puntos (para cron job)
router.post('/expire-points', authenticate, authorize('ADMIN'), async (req, res, next) => {
  try {
    const result = await PointsExpirationService.expirePoints();
    res.json(result);
  } catch (error) {
    next(error);
  }
});

// Enviar bonos de cumpleaños del día (para cron job diario)
router.post('/birthday-bonus', authenticate, authorize('ADMIN'), async (req, res, next) => {
  try {
    const today = new Date();
    const month = today.getMonth() + 1;
    const day = today.getDate();
    
    const users = await prisma.user.findMany({
      where: {
        role: 'CLIENTE',
        isActive: true,
        birthDate: {
          not: null,
        },
      },
      include: { clientProfile: true },
    });
    
    let processed = 0;
    let errors: string[] = [];
    
    for (const user of users) {
      if (!user.birthDate) continue;
      
      const birthMonth = user.birthDate.getMonth() + 1;
      const birthDay = user.birthDate.getDate();
      
      if (birthMonth === month && birthDay === day) {
        if (!user.clientProfile) continue;
        
        const tier = await prisma.tierConfig.findUnique({
          where: { name: user.clientProfile.tier },
        });
        
        const bonusPoints = tier?.birthdayBonusPoints || 0;
        if (bonusPoints <= 0 || !user.clientProfile) continue;
        
        const currentPoints = user.clientProfile.currentPoints;
        
        try {
          // Add birthday bonus points
          await prisma.$transaction(async (tx) => {
            await tx.clientProfile.update({
              where: { userId: user.id },
              data: {
                currentPoints: { increment: bonusPoints },
                totalPointsEarned: { increment: bonusPoints },
              },
            });
            
            await tx.transaction.create({
              data: {
                userId: user.id,
                type: 'BONIFICACION',
                subtotal: 0,
                total: 0,
                pointsEarned: bonusPoints,
                pointsBalance: currentPoints + bonusPoints,
                description: 'Bono de cumpleaños',
              },
            });
            
            await tx.notification.create({
              data: {
                userId: user.id,
                type: 'BIRTHDAY_BONUS',
                title: '¡Feliz Cumpleaños!',
                message: `Te regalamos ${bonusPoints} puntos por tu cumpleaños`,
                metadata: { points: bonusPoints },
              },
            });
          });
          
          // Send email
          if (user.email) {
            await emailService.sendBirthdayBonusEmail(user.email, user.firstName, bonusPoints);
          }
          
          // Send WhatsApp
          if (user.phone) {
            const body = `🎂 *¡Feliz Cumpleaños ${user.firstName}!*\n\nTe regalamos *${bonusPoints} puntos* por tu día.\nTu nuevo saldo: *${(user.clientProfile?.currentPoints || 0) + bonusPoints} puntos* 🎁\n\nClub Pinturería 🎨`;
            await whatsappService.sendMessage(user.phone, body);
          }
          
          processed++;
        } catch (err) {
          errors.push(`Error con ${user.dni}: ${err}`);
        }
      }
    }
    
    res.json({ processed, errors });
  } catch (error) {
    next(error);
  }
});

// Notificar puntos por vencer (para cron job diario)
router.post('/notify-expiring', authenticate, authorize('ADMIN'), async (req, res, next) => {
  try {
    // This is handled within expirePoints, but can be called separately
    const result = await PointsExpirationService.expirePoints();
    res.json({ message: 'Notificaciones enviadas', ...result });
  } catch (error) {
    next(error);
  }
});

// Enviar email de bienvenida a nuevos clientes
router.post('/welcome-email', authenticate, authorize('ADMIN'), validate(z.object({
  body: z.object({
    dni: z.string().min(7).max(8),
  }),
})), async (req, res, next) => {
  try {
    const { dni } = req.body;
    const user = await prisma.user.findUnique({ where: { dni } });
    
    if (!user) throw new Error('Cliente no encontrado');
    if (!user.email) throw new Error('Cliente sin email');
    
    await emailService.sendWelcomeEmail(user.email, user.firstName);
    
    // Send WhatsApp welcome
    if (user.phone) {
      const body = `👋 *¡Bienvenido ${user.firstName} a Club Pinturería!*\n\nTu cuenta está lista para empezar a ganar puntos en cada compra. Presentá tu DNI en la sucursal y comenzá a sumar.\n\nClub Pinturería 🎨`;
      await whatsappService.sendMessage(user.phone, body);
    }
    
    res.json({ message: 'Email de bienvenida enviado' });
  } catch (error) {
    next(error);
  }
});

// Manual expire points for specific client
router.post('/expire-client', authenticate, authorize('ADMIN'), validate(z.object({
  body: z.object({
    dni: z.string().min(7).max(8),
  }),
})), async (req, res, next) => {
  try {
    const { dni } = req.body;
    const result = await PointsExpirationService.expirePointsForClient(dni);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

export default router;