import { Router } from 'express';
import { z } from 'zod';
import { validate } from '../middleware/validation';
import { PromotionService } from '../services/promotion.service';
import { CouponService } from '../services/coupon.service';
import { ChallengeService } from '../services/challenge.service';
import { PurchaseService } from '../services/purchase.service';
import { BenefitService } from '../services/benefit.service';
import { prisma } from '../config/prisma';
import { AppError } from '../middleware/errorHandler';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();

// Todas las rutas requieren autenticación de cliente
router.use(authenticate);

// ===== HOME CLIENTE =====
router.get('/home', async (req, res, next) => {
  try {
    const user = (req as AuthRequest).user!;
    
    const client = await prisma.user.findUnique({
      where: { id: user.id },
      include: {
        clientProfile: true,
        qr: true,
      },
    });

    if (!client || !client.clientProfile) {
      throw new AppError(404, 'Perfil de cliente no encontrado');
    }

    const profile = client.clientProfile;
    const tierConfig = await prisma.tierConfig.findUnique({
      where: { name: profile.tier },
    });

    const nextTier = await prisma.tierConfig.findFirst({
      where: {
        minPoints: { gt: profile.currentPoints },
        isActive: true,
      },
      orderBy: { minPoints: 'asc' },
    });

    // Promociones activas para el cliente
    const promotions = await PromotionService.getActivePromotionsForClient(
      profile.tier,
      [],
      0,
      [],
      [],
      []
    );

    // Desafíos activos
    const challenges = await ChallengeService.getClientChallenges(user.id);

    // Cupones disponibles
    const coupons = await CouponService.getCoupons({
      clientId: user.id,
      isActive: true,
      page: 1,
      limit: 5,
    });

    // Últimas compras
    const recentPurchases = await PurchaseService.getPurchases({
      clientId: user.id,
      page: 1,
      limit: 5,
    });

    // Cupones por vencer (próximos 7 días)
    const expiringCoupons = await prisma.coupon.findMany({
      where: {
        clientId: user.id,
        isActive: true,
        endDate: {
          gte: new Date(),
          lte: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        },
      },
      take: 3,
      orderBy: { endDate: 'asc' },
    });

    // Beneficios disponibles para el tier del cliente
    const benefits = await BenefitService.getActiveBenefitsForTier(profile.tier);

    res.json({
      client: {
        firstName: client.firstName,
        lastName: client.lastName,
        dni: client.dni,
        email: client.email,
        phone: client.phone,
        birthDate: client.birthDate,
      },
      profile: {
        currentPoints: profile.currentPoints,
        totalPointsEarned: profile.totalPointsEarned,
        totalPointsRedeemed: profile.totalPointsRedeemed,
        tier: profile.tier,
        tierLabel: tierConfig?.label || profile.tier,
        tierColor: tierConfig?.color || '#6B7280',
        tierMultiplier: tierConfig?.pointsMultiplier || 1,
        birthdayBonusPoints: tierConfig?.birthdayBonusPoints || 0,
        pointsExpiryDays: tierConfig?.pointsExpiryDays,
        lastPurchaseAt: profile.lastPurchaseAt,
      },
      nextTier: nextTier ? {
        name: nextTier.name,
        label: nextTier.label,
        minPoints: nextTier.minPoints,
        pointsNeeded: nextTier.minPoints - profile.currentPoints,
        multiplier: nextTier.pointsMultiplier,
      } : null,
      stats: {
        activePromotions: promotions.length,
        activeChallenges: challenges.filter(c => !c.progress?.completed).length,
        availableCoupons: coupons.coupons.length,
        expiringCoupons: expiringCoupons.length,
      },
      promotions: promotions.slice(0, 3).map(p => ({
        id: p.promotion.id,
        name: p.promotion.name,
        type: p.promotion.type,
        multiplier: p.promotion.multiplier,
        bonusPoints: p.promotion.bonusPoints,
        discount: p.promotion.discount,
        endDate: p.promotion.endDate,
      })),
      challenges: challenges.slice(0, 3).map(c => ({
        id: c.id,
        name: c.name,
        description: c.description,
        type: c.type,
        target: c.target,
        progress: c.progress?.currentValue || 0,
        completed: c.progress?.completed || false,
        rewardPoints: c.rewardPoints,
        endDate: c.endDate,
      })),
      coupons: coupons.coupons.slice(0, 3).map(c => ({
        id: c.id,
        code: c.code,
        name: c.name,
        type: c.type,
        value: c.value,
        endDate: c.endDate,
      })),
      expiringCoupons: expiringCoupons.map(c => ({
        id: c.id,
        code: c.code,
        name: c.name,
        daysLeft: Math.ceil((new Date(c.endDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)),
      })),
      recentPurchases: recentPurchases.purchases.slice(0, 3).map(p => ({
        id: p.id,
        receiptNumber: p.receiptNumber,
        total: p.total,
        pointsEarned: p.pointsEarned,
        createdAt: p.createdAt,
      })),
      benefits: benefits.map(b => ({
        id: b.id,
        name: b.name,
        description: b.description,
        imageUrl: b.imageUrl,
        type: b.type,
        value: b.value,
        tierRequired: b.tierRequired,
        autoApply: b.autoApply,
        endDate: b.endDate,
      })),
    });
  } catch (error) {
    next(error);
  }
});

// ===== MIS PROMOCIONES =====
router.get('/promotions', async (req, res, next) => {
  try {
    const user = (req as AuthRequest).user!;
    const client = await prisma.user.findUnique({
      where: { id: user.id },
      include: { clientProfile: true },
    });

    if (!client?.clientProfile) throw new AppError(404, 'Perfil no encontrado');

    const { page = 1, limit = 20 } = req.query;

    const promotions = await PromotionService.getActivePromotionsForClient(
      client.clientProfile.tier,
      [],
      0,
      [],
      [],
      []
    );

    const allPromotions = await prisma.promotion.findMany({
      where: {
        isActive: true,
        startDate: { lte: new Date() },
        endDate: { gte: new Date() },
        tiers: { has: client.clientProfile.tier },
      },
      orderBy: { createdAt: 'desc' },
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
    });

    const total = await prisma.promotion.count({
      where: {
        isActive: true,
        startDate: { lte: new Date() },
        endDate: { gte: new Date() },
        tiers: { has: client.clientProfile.tier },
      },
    });

    res.json({
      promotions: allPromotions.map(p => ({
        id: p.id,
        name: p.name,
        description: p.description,
        imageUrl: p.imageUrl,
        type: p.type,
        multiplier: p.multiplier,
        bonusPoints: p.bonusPoints,
        discount: p.discount,
        startDate: p.startDate,
        endDate: p.endDate,
        categories: p.categories,
        brands: p.brands,
        products: p.products,
      })),
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    next(error);
  }
});

// ===== MIS CUPONES =====
router.get('/coupons', async (req, res, next) => {
  try {
    const user = (req as AuthRequest).user!;
    const { page = 1, limit = 20, status } = req.query;

    const filters: any = {
      clientId: user.id,
      page: Number(page),
      limit: Number(limit),
    };

    if (status === 'available') {
      filters.isActive = true;
    } else if (status === 'used') {
      filters.isActive = false;
    }

    const result = await CouponService.getCoupons(filters);
    
    // Agregar días restantes
    const couponsWithDays = result.coupons.map(c => ({
      ...c,
      daysLeft: c.endDate ? Math.ceil((new Date(c.endDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : null,
      isExpired: c.endDate ? new Date(c.endDate) < new Date() : false,
      isExpiringSoon: c.endDate ? (new Date(c.endDate).getTime() - Date.now()) < 7 * 24 * 60 * 60 * 1000 : false,
    }));

    res.json({
      coupons: couponsWithDays,
      pagination: result.pagination,
    });
  } catch (error) {
    next(error);
  }
});

// Validar cupón
router.post('/coupons/validate', async (req, res, next) => {
  try {
    const user = (req as AuthRequest).user!;
    const { code } = req.body;

    if (!code) throw new AppError(400, 'Código requerido');

    const result = await CouponService.validateCoupon(code, user.id);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

// ===== MIS DESAFÍOS =====
router.get('/challenges', async (req, res, next) => {
  try {
    const user = (req as AuthRequest).user!;
    const challenges = await ChallengeService.getClientChallenges(user.id);
    
    res.json({
      challenges: challenges.map(c => {
        const prog = c.progress as { currentValue: number; completed: boolean; completedAt: Date | null } | undefined;
        return {
          id: c.id,
          name: c.name,
          description: c.description,
          imageUrl: c.imageUrl,
          type: c.type,
          target: c.target,
          progress: prog?.currentValue ?? 0,
          completed: prog?.completed ?? false,
          completedAt: prog?.completedAt ?? null,
          rewardPoints: c.rewardPoints,
          rewardCoupon: c.rewardCoupon,
          startDate: c.startDate,
          endDate: c.endDate,
        };
      }),
    });
  } catch (error) {
    next(error);
  }
});

// ===== MI QR =====
router.get('/qr', async (req, res, next) => {
  try {
    const user = (req as AuthRequest).user!;

    let qr = await prisma.customerQR.findUnique({
      where: { clientId: user.id },
    });

    if (!qr) {
      qr = await prisma.customerQR.create({
        data: {
          clientId: user.id,
          token: require('crypto').randomBytes(32).toString('hex'),
        },
      });
    }

    // Generar URL del QR
    const qrUrl = `${process.env.FRONTEND_URL || 'http://localhost:5173'}/scan/${qr.token}`;
    
    // Generar QR como SVG o data URL
    const QRCode = require('qrcode');
    const qrSvg = await QRCode.toString(qrUrl, { type: 'svg', width: 300 });

    res.json({
      qr: {
        id: qr.id,
        token: qr.token,
        url: qrUrl,
        svg: qrSvg,
        expiresAt: qr.expiresAt,
        createdAt: qr.createdAt,
      },
      client: {
        firstName: (req as AuthRequest).user!.firstName,
        lastName: (req as AuthRequest).user!.lastName,
        dni: (req as AuthRequest).user!.dni,
      },
    });
  } catch (error) {
    next(error);
  }
});

// Regenerar QR
router.post('/qr/regenerate', async (req, res, next) => {
  try {
    const user = (req as AuthRequest).user!;

    await prisma.customerQR.deleteMany({
      where: { clientId: user.id },
    });

    const qr = await prisma.customerQR.create({
      data: {
        clientId: user.id,
        token: require('crypto').randomBytes(32).toString('hex'),
      },
    });

    const qrUrl = `${process.env.FRONTEND_URL || 'http://localhost:5173'}/scan/${qr.token}`;
    const QRCode = require('qrcode');
    const qrSvg = await QRCode.toString(qrUrl, { type: 'svg', width: 300 });

    res.json({
      qr: {
        id: qr.id,
        token: qr.token,
        url: qrUrl,
        svg: qrSvg,
        createdAt: qr.createdAt,
      },
    });
  } catch (error) {
    next(error);
  }
});

// ===== MIS COMPRAS =====
router.get('/purchases', async (req, res, next) => {
  try {
    const user = (req as AuthRequest).user!;
    const { page = 1, limit = 20, startDate, endDate } = req.query;

    const result = await PurchaseService.getPurchases({
      clientId: user.id,
      page: Number(page),
      limit: Number(limit),
      startDate: startDate ? new Date(startDate as string) : undefined,
      endDate: endDate ? new Date(endDate as string) : undefined,
    });

    res.json({
      purchases: result.purchases.map(p => ({
        id: p.id,
        receiptNumber: p.receiptNumber,
        total: p.total,
        pointsEarned: p.pointsEarned,
        status: p.status,
        createdAt: p.createdAt,
        branch: p.branch,
        itemCount: p.itemCount,
      })),
      pagination: result.pagination,
    });
  } catch (error) {
    next(error);
  }
});

router.get('/purchases/:id', async (req, res, next) => {
  try {
    const user = (req as AuthRequest).user!;
    const { id } = req.params;

    const purchase = await PurchaseService.getPurchaseById(id);
    if (!purchase) throw new AppError(404, 'Compra no encontrada');
    if (purchase.client.id !== user.id) throw new AppError(403, 'No autorizado');

    res.json(purchase);
  } catch (error) {
    next(error);
  }
});

// ===== PERFIL PROFESIONAL =====
router.get('/professional', async (req, res, next) => {
  try {
    const user = (req as AuthRequest).user!;
    const profile = await prisma.professionalProfile.findUnique({
      where: { clientId: user.id },
    });

    res.json({ profile });
  } catch (error) {
    next(error);
  }
});

router.put('/professional', async (req, res, next) => {
  try {
    const user = (req as AuthRequest).user!;
    const { specialty, company, position, location, phone, website, socialMedia, preferredBrands, preferredCategories } = req.body;

    const profile = await prisma.professionalProfile.upsert({
      where: { clientId: user.id },
      update: { specialty, company, position, location, phone, website, socialMedia, preferredBrands, preferredCategories },
      create: { clientId: user.id, specialty, company, position, location, phone, website, socialMedia, preferredBrands, preferredCategories },
    });

    res.json({ profile });
  } catch (error) {
    next(error);
  }
});

export default router;