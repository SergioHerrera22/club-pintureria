import { Router } from 'express';
import { z } from 'zod';
import { validate } from '../middleware/validation';
import * as tierConfigController from '../controllers/tierConfig.controller';
import { authenticate, authorize } from '../middleware/auth';

const router = Router();

router.get('/', authenticate, authorize('CAJERA', 'ADMIN'), tierConfigController.getTierConfigs);
router.get('/client/:dni', tierConfigController.getClientTier);
router.get('/:id', authenticate, authorize('CAJERA', 'ADMIN'), tierConfigController.getTierConfigById);

router.post('/', authenticate, authorize('ADMIN'), validate(z.object({
  body: z.object({
    name: z.string().min(1),
    label: z.string().min(1),
    minPoints: z.number().int().nonnegative().default(0),
    maxPoints: z.number().int().nonnegative().optional().nullable(),
    color: z.string().regex(/^#[0-9A-Fa-f]{6}$/).default('#6B7280'),
    pointsMultiplier: z.number().positive().default(1.0),
    pointsExpiryDays: z.number().int().positive().optional().nullable(),
    birthdayBonusPoints: z.number().int().nonnegative().default(0),
    isActive: z.boolean().default(true),
    sortOrder: z.number().int().default(0),
  }),
})), tierConfigController.createTierConfig);

router.put('/:id', authenticate, authorize('ADMIN'), validate(z.object({
  body: z.object({
    name: z.string().min(1).optional(),
    label: z.string().min(1).optional(),
    minPoints: z.number().int().nonnegative().optional(),
    maxPoints: z.number().int().nonnegative().optional().nullable(),
    color: z.string().regex(/^#[0-9A-Fa-f]{6}$/).optional(),
    pointsMultiplier: z.number().positive().optional(),
    pointsExpiryDays: z.number().int().positive().optional().nullable(),
    birthdayBonusPoints: z.number().int().nonnegative().optional(),
    isActive: z.boolean().optional(),
    sortOrder: z.number().int().optional(),
  }),
  params: z.object({ id: z.string() }),
})), tierConfigController.updateTierConfig);

router.delete('/:id', authenticate, authorize('ADMIN'), tierConfigController.deleteTierConfig);
router.post('/initialize-defaults', authenticate, authorize('ADMIN'), tierConfigController.initializeDefaultTiers);

export default router;