import { Router } from 'express';
import { z } from 'zod';
import { validate } from '../middleware/validation';
import * as clientController from '../controllers/client.controller';
import { authenticate, authorize } from '../middleware/auth';

const router = Router();

router.get('/', authenticate, authorize('CAJERA', 'ADMIN'), clientController.listClients);
router.get('/:id', authenticate, authorize('CAJERA', 'ADMIN'), clientController.getClientDetail);
router.get('/dni/:dni', authenticate, authorize('CAJERA', 'ADMIN'), clientController.findClientByDni);
router.get('/dni/:dni/points', clientController.getClientPoints);
router.get('/dni/:dni/history', authenticate, authorize('CAJERA', 'ADMIN'), clientController.getClientHistory);

router.put('/:id', authenticate, authorize('CAJERA', 'ADMIN'), validate(z.object({
  body: z.object({
    firstName: z.string().min(1).optional(),
    lastName: z.string().min(1).optional(),
    email: z.string().email().optional(),
    phone: z.string().optional(),
    birthDate: z.string().optional(),
    isActive: z.boolean().optional(),
  }),
  params: z.object({ id: z.string() }),
})), clientController.updateClient);

router.delete('/:id', authenticate, authorize('ADMIN'), clientController.deleteClient);

const purchaseSchema = z.object({
  body: z.object({
    dni: z.string().min(7).max(8),
    items: z.array(z.object({
      productId: z.string(),
      quantity: z.number().int().positive().default(1),
    })).min(1),
    paymentMethod: z.string().optional(),
    notes: z.string().optional(),
    // Optional fields for auto-creating new client
    firstName: z.string().min(1).optional(),
    lastName: z.string().min(1).optional(),
    email: z.string().email().optional(),
    phone: z.string().optional(),
    birthDate: z.string().optional(),
  }),
});

const quickPurchaseSchema = z.object({
  body: z.object({
    dni: z.string().min(7).max(8),
    amount: z.number().positive(),
    notes: z.string().optional(),
    // Optional fields for auto-creating new client
    firstName: z.string().min(1).optional(),
    lastName: z.string().min(1).optional(),
    email: z.string().email().optional(),
    phone: z.string().optional(),
    birthDate: z.string().optional(),
  }),
});

router.post('/purchase', authenticate, authorize('CAJERA', 'ADMIN'), validate(purchaseSchema), clientController.registerPurchase);
router.post('/quick-purchase', authenticate, authorize('CAJERA', 'ADMIN'), validate(quickPurchaseSchema), clientController.registerQuickPurchase);

// Tier change management (ADMIN only)
router.get('/tier-changes/pending', authenticate, authorize('ADMIN'), clientController.getPendingTierChanges);
router.post('/:id/tier-change/approve', authenticate, authorize('ADMIN'), clientController.approveTierChange);
router.get('/:id/tier-history', authenticate, authorize('ADMIN'), clientController.getClientTierHistory);

export default router;