import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/prisma';
import { AppError } from '../middleware/errorHandler';
import { AuthRequest } from '../middleware/auth';

export const getSystemConfigs = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const configs = await prisma.systemConfig.findMany({
      orderBy: { key: 'asc' },
    });
    
    res.json({ configs });
  } catch (error) {
    next(error);
  }
};

export const getSystemConfigByKey = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { key } = req.params;
    const config = await prisma.systemConfig.findUnique({ where: { key } });
    if (!config) throw new AppError(404, 'Configuración no encontrada');
    res.json(config);
  } catch (error) {
    next(error);
  }
};

export const updateSystemConfig = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { key } = req.params;
    const { value, description } = req.body;
    
    const config = await prisma.systemConfig.upsert({
      where: { key },
      update: { value, description },
      create: { key, value, description },
    });
    
    res.json(config);
  } catch (error) {
    next(error);
  }
};

export const deleteSystemConfig = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { key } = req.params;
    await prisma.systemConfig.delete({ where: { key } });
    res.json({ message: 'Configuración eliminada' });
  } catch (error) {
    next(error);
  }
};

export const initializeDefaultConfigs = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const defaultConfigs = [
      {
        key: 'points_per_currency',
        value: { rate: 1, currency: 'ARS' },
        description: 'Puntos por unidad de moneda (ej: 1 punto por $100 ARS)',
      },
      {
        key: 'welcome_points',
        value: { points: 100 },
        description: 'Puntos de bienvenida para nuevos clientes',
      },
      {
        key: 'birthday_bonus_enabled',
        value: { enabled: true },
        description: 'Habilitar bono de cumpleaños automático',
      },
      {
        key: 'email_notifications_enabled',
        value: { enabled: true },
        description: 'Habilitar notificaciones por email',
      },
      {
        key: 'whatsapp_notifications_enabled',
        value: { enabled: false },
        description: 'Habilitar notificaciones por WhatsApp',
      },
      {
        key: 'points_expiry_warning_days',
        value: { days: 7 },
        description: 'Días de antelación para avisar sobre vencimiento de puntos',
      },
      {
        key: 'min_purchase_for_points',
        value: { amount: 1000 },
        description: 'Monto mínimo de compra para generar puntos',
      },
      {
        key: 'max_points_per_purchase',
        value: { limit: 10000 },
        description: 'Máximo de puntos que se pueden ganar en una sola compra',
      },
      {
        key: 'redemption_min_points',
        value: { points: 100 },
        description: 'Mínimo de puntos requeridos para canjear premios',
      },
      {
        key: 'company_name',
        value: { name: 'Club Pinturería' },
        description: 'Nombre de la empresa para comunicaciones',
      },
      {
        key: 'company_logo_url',
        value: { url: '' },
        description: 'URL del logo de la empresa',
      },
      {
        key: 'support_email',
        value: { email: 'soporte@clubpintureria.com' },
        description: 'Email de soporte para comunicaciones',
      },
      {
        key: 'support_phone',
        value: { phone: '+54 11 1234-5678' },
        description: 'Teléfono de soporte',
      },
    ];
    
    for (const config of defaultConfigs) {
      await prisma.systemConfig.upsert({
        where: { key: config.key },
        update: { value: config.value, description: config.description },
        create: config,
      });
    }
    
    const configs = await prisma.systemConfig.findMany({ orderBy: { key: 'asc' } });
    res.json({ configs });
  } catch (error) {
    next(error);
  }
};