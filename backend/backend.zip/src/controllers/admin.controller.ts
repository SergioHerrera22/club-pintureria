import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/prisma';
import { PointsService } from '../services/points.service';
import { AppError } from '../middleware/errorHandler';
import { AuthRequest } from '../middleware/auth';
import { UserRole, Prisma } from '@prisma/client';
import bcrypt from 'bcryptjs';

export const getUsers = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { page = 1, limit = 20, search, role, isActive, branchId } = req.query;
    
    const where: Prisma.UserWhereInput = {};
    if (search) {
      where.OR = [
        { firstName: { contains: search as string, mode: 'insensitive' } },
        { lastName: { contains: search as string, mode: 'insensitive' } },
        { dni: { contains: search as string } },
        { email: { contains: search as string, mode: 'insensitive' } },
      ];
    }
    if (role) where.role = role as UserRole;
    if (isActive !== undefined) where.isActive = isActive === 'true';
    if (branchId) where.branchId = branchId as string;
    
    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (Number(page) - 1) * Number(limit),
        take: Number(limit),
        include: { clientProfile: true, branch: true },
      }),
      prisma.user.count({ where }),
    ]);
    
    res.json({
      users: users.map(u => ({
        id: u.id,
        email: u.email,
        firstName: u.firstName,
        lastName: u.lastName,
        dni: u.dni,
        phone: u.phone,
        role: u.role,
        isActive: u.isActive,
        createdAt: u.createdAt,
        clientProfile: u.clientProfile,
        branch: u.branch,
      })),
      pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) },
    });
  } catch (error) {
    next(error);
  }
};

export const getUserById = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const user = await prisma.user.findUnique({
      where: { id },
      include: { clientProfile: true, branch: true },
    });
    
    if (!user) throw new AppError(404, 'Usuario no encontrado');
    
    res.json({
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      dni: user.dni,
      phone: user.phone,
      birthDate: user.birthDate,
      role: user.role,
      isActive: user.isActive,
      createdAt: user.createdAt,
      clientProfile: user.clientProfile,
      branch: user.branch,
    });
  } catch (error) {
    next(error);
  }
};

export const createUser = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { email, password, firstName, lastName, dni, phone, birthDate, role = 'CLIENTE', branchId } = req.body;
    
    const existing = await prisma.user.findFirst({ where: { OR: [{ email }, { dni }] } });
    if (existing) throw new AppError(409, 'Email o DNI ya registrado');
    
    if (branchId) {
      const branch = await prisma.branch.findUnique({ where: { id: branchId } });
      if (!branch) throw new AppError(404, 'Sucursal no encontrada');
    }
    
    const passwordHash = await bcrypt.hash(password, 12);
    
    const user = await prisma.user.create({
      data: {
        email,
        passwordHash,
        firstName,
        lastName,
        dni,
        phone,
        birthDate: birthDate ? new Date(birthDate) : null,
        role: role as UserRole,
        branchId: branchId || null,
      },
      include: { branch: true },
    });
    
    if (role === 'CLIENTE') {
      await prisma.clientProfile.create({ data: { userId: user.id } });
    }
    
    res.status(201).json({ id: user.id, email: user.email, firstName: user.firstName, lastName: user.lastName, dni: user.dni, role: user.role, branch: user.branch });
  } catch (error) {
    next(error);
  }
};

export const updateUser = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const { firstName, lastName, phone, birthDate, role, isActive, branchId } = req.body;
    
    if (branchId) {
      const branch = await prisma.branch.findUnique({ where: { id: branchId } });
      if (!branch) throw new AppError(404, 'Sucursal no encontrada');
    }
    
    const user = await prisma.user.update({
      where: { id },
      data: { 
        firstName, 
        lastName, 
        phone, 
        birthDate: birthDate ? new Date(birthDate) : undefined, 
        role, 
        isActive,
        branchId: branchId !== undefined ? branchId : undefined,
      },
      include: { branch: true },
    });
    
    res.json({ id: user.id, email: user.email, firstName: user.firstName, lastName: user.lastName, dni: user.dni, role: user.role, isActive: user.isActive, branch: user.branch });
  } catch (error) {
    next(error);
  }
};

export const deleteUser = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    await prisma.user.delete({ where: { id } });
    res.json({ message: 'Usuario eliminado' });
  } catch (error) {
    next(error);
  }
};

export const adjustPoints = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { userId, points, reason } = req.body;
    
    await PointsService.adjustPoints(userId, points, reason, req.user!.id);
    
    const profile = await prisma.clientProfile.findUnique({ where: { userId } });
    res.json({ message: 'Puntos ajustados', currentPoints: profile?.currentPoints });
  } catch (error) {
    next(error);
  }
};