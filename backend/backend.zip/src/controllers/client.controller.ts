import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/prisma';
import { PointsService } from '../services/points.service';
import { PurchaseService } from '../services/purchase.service';
import { emailService } from '../services/email.service';
import { whatsappService } from '../services/whatsapp.service';
import { AppError } from '../middleware/errorHandler';
import { AuthRequest } from '../middleware/auth';
import { TransactionType, Prisma, UserRole } from '@prisma/client';

export const listClients = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { page = 1, limit = 20, search, tier, isActive, sortBy = 'createdAt', sortOrder = 'desc' } = req.query;
    
    const where: Prisma.UserWhereInput = { role: UserRole.CLIENTE };
    
    if (search) {
      const searchStr = search as string;
      where.OR = [
        { firstName: { contains: searchStr, mode: 'insensitive' } },
        { lastName: { contains: searchStr, mode: 'insensitive' } },
        { dni: { contains: searchStr, mode: 'insensitive' } },
        { email: { contains: searchStr, mode: 'insensitive' } },
      ];
    }
    
    if (tier) {
      where.clientProfile = { tier: tier as string };
    }
    
    if (isActive !== undefined) {
      where.isActive = isActive === 'true';
    }
    
    const validSortFields = ['createdAt', 'firstName', 'lastName', 'dni', 'email'] as const;
    type SortField = typeof validSortFields[number];
    const sortField = validSortFields.includes(sortBy as SortField) ? sortBy as SortField : 'createdAt';
    const orderBy: Prisma.UserOrderByWithRelationInput = { [sortField]: sortOrder === 'asc' ? 'asc' : 'desc' };
    
    const [clients, total] = await Promise.all([
      prisma.user.findMany({
        where,
        orderBy,
        skip: (Number(page) - 1) * Number(limit),
        take: Number(limit),
        include: { clientProfile: true },
      }),
      prisma.user.count({ where }),
    ]);
    
    res.json({
      clients: clients.map(u => ({
        id: u.id,
        firstName: u.firstName,
        lastName: u.lastName,
        dni: u.dni,
        email: u.email,
        phone: u.phone,
        birthDate: u.birthDate,
        isActive: u.isActive,
        createdAt: u.createdAt,
        clientProfile: u.clientProfile ? {
          currentPoints: u.clientProfile.currentPoints,
          totalPointsEarned: u.clientProfile.totalPointsEarned,
          totalPointsRedeemed: u.clientProfile.totalPointsRedeemed,
          tier: u.clientProfile.tier,
          lastPurchaseAt: u.clientProfile.lastPurchaseAt,
        } : null,
      })),
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    next(error);
  }
};

export const updateClient = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const { firstName, lastName, email, phone, birthDate, isActive } = req.body;
    
    const user = await prisma.user.update({
      where: { id },
      data: { firstName, lastName, email, phone, birthDate: birthDate ? new Date(birthDate) : null, isActive },
      include: { clientProfile: true },
    });
    
    res.json({
      id: user.id,
      firstName: user.firstName,
      lastName: user.lastName,
      dni: user.dni,
      email: user.email,
      phone: user.phone,
      birthDate: user.birthDate,
      isActive: user.isActive,
      clientProfile: user.clientProfile,
    });
  } catch (error) {
    next(error);
  }
};

export const deleteClient = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    
    await prisma.$transaction(async (tx) => {
      // Delete related records in order (due to foreign key constraints)
      await tx.purchaseItem.deleteMany({
        where: { purchase: { clientId: id } },
      });
      
      await tx.purchase.deleteMany({
        where: { clientId: id },
      });
      
      await tx.transactionItem.deleteMany({
        where: { transaction: { userId: id } },
      });
      
      await tx.transaction.deleteMany({
        where: { userId: id },
      });
      
      await tx.redemption.deleteMany({
        where: { userId: id },
      });
      
      await tx.notification.deleteMany({
        where: { userId: id },
      });
      
      await tx.coupon.deleteMany({
        where: { clientId: id },
      });
      
      await tx.challengeProgress.deleteMany({
        where: { clientId: id },
      });
      
      await tx.professionalProfile.deleteMany({
        where: { clientId: id },
      });
      
      await tx.customerQR.deleteMany({
        where: { clientId: id },
      });
      
      await tx.clientProfile.deleteMany({
        where: { userId: id },
      });
      
      // Finally delete the user
      await tx.user.delete({ where: { id } });
    });
    
    res.json({ message: 'Cliente eliminado correctamente' });
  } catch (error) {
    next(error);
  }
};

export const getClientDetail = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    
    const user = await prisma.user.findUnique({
      where: { id },
      include: { clientProfile: true },
    });
    
    if (!user) throw new AppError(404, 'Cliente no encontrado');
    
    const recentTransactions = await prisma.transaction.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 10,
      include: { items: { include: { product: true } } },
    });
    
    // Also fetch purchases with points breakdown
    const recentPurchases = await prisma.purchase.findMany({
      where: { clientId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 10,
      include: { 
        items: { include: { product: { select: { id: true, name: true, code: true } } } },
      },
    });

    // Combine and sort by date
    const transactionMovements = recentTransactions.map(t => ({
      id: t.id,
      type: t.type,
      total: Number(t.total),
      pointsEarned: t.pointsEarned,
      pointsBalance: t.pointsBalance,
      description: t.description,
      createdAt: t.createdAt,
      items: t.items.map(i => ({
        productName: i.product.name,
        quantity: i.quantity,
        unitPrice: Number(i.unitPrice),
        lineTotal: Number(i.lineTotal),
      })),
      pointsBreakdown: undefined,
      receiptNumber: undefined,
    }));

    const purchaseMovements = (recentPurchases as any[]).map(p => ({
      id: p.id,
      type: 'COMPRA' as const,
      total: Number(p.total),
      pointsEarned: p.pointsEarned,
      pointsBalance: p.pointsBalance,
      description: p.notes,
      createdAt: p.createdAt,
      items: (p.items as any[]).map(i => ({
        productName: i.product.name,
        quantity: i.quantity,
        unitPrice: Number(i.unitPrice),
        lineTotal: Number(i.lineTotal),
      })),
      pointsBreakdown: p.pointsBreakdown || [],
      receiptNumber: p.receiptNumber,
    }));

    const allMovements = [...transactionMovements, ...purchaseMovements]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 10);
    
    res.json({
      id: user.id,
      firstName: user.firstName,
      lastName: user.lastName,
      dni: user.dni,
      email: user.email,
      phone: user.phone,
      birthDate: user.birthDate,
      isActive: user.isActive,
      createdAt: user.createdAt,
      clientProfile: user.clientProfile,
      recentTransactions: allMovements.map(t => ({
        id: t.id,
        type: t.type,
        total: Number(t.total),
        pointsEarned: t.pointsEarned,
        pointsBalance: t.pointsBalance,
        description: t.description,
        createdAt: t.createdAt,
        items: t.items || [],
        pointsBreakdown: t.pointsBreakdown || [],
        receiptNumber: t.receiptNumber,
      })),
    });
  } catch (error) {
    next(error);
  }
};

export const findClientByDni = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { dni } = req.params;
    
    // Clean DNI - remove dots, dashes, spaces
    const cleanDni = dni.replace(/[.\-\s]/g, '');
    
    // Try exact match first
    let user = await prisma.user.findUnique({
      where: { dni: cleanDni },
      include: { clientProfile: true },
    });
    
    // If not found, try finding by contains in BOTH directions
    if (!user) {
      const users = await prisma.user.findMany({
        where: {
          role: 'CLIENTE',
        },
        include: { clientProfile: true },
      });
      
      // Find best match: compare cleaned versions
      user = users.find(u => u.dni.replace(/[.\-\s]/g, '') === cleanDni)
        || users.find(u => u.dni.replace(/[.\-\s]/g, '').includes(cleanDni))
        || users.find(u => cleanDni.includes(u.dni.replace(/[.\-\s]/g, '')))
        || null;
    }
    
    if (!user) {
      throw new AppError(404, 'Cliente no encontrado');
    }
    
    if (!user.isActive) {
      throw new AppError(403, 'Cliente inactivo');
    }
    
    // Ensure clientProfile exists
    let clientProfile = user.clientProfile;
    if (!clientProfile) {
      clientProfile = await prisma.clientProfile.create({
        data: { userId: user.id },
      });
    }
    
    res.json({
      id: user.id,
      firstName: user.firstName,
      lastName: user.lastName,
      dni: user.dni,
      email: user.email,
      phone: user.phone,
      birthDate: user.birthDate,
      isActive: user.isActive,
      clientProfile,
    });
  } catch (error) {
    next(error);
  }
};

export const registerPurchase = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { dni, items, paymentMethod, notes, firstName, lastName, email, phone, birthDate } = req.body;
    
    if (!items || !Array.isArray(items) || items.length === 0) {
      throw new AppError(400, 'Debe agregar al menos un producto');
    }
    
    // Clean DNI - remove dots, dashes, spaces
    const cleanDni = dni.replace(/[.\-\s]/g, '');
    
    // Try exact match first
    let user = await prisma.user.findUnique({
      where: { dni: cleanDni },
      include: { clientProfile: true },
    });
    
    // If not found, try finding by contains
    if (!user) {
      const users = await prisma.user.findMany({
        where: {
          dni: {
            contains: cleanDni,
            mode: 'insensitive',
          },
          role: 'CLIENTE',
        },
        include: { clientProfile: true },
      });
      
      user = users.find(u => u.dni.replace(/[.\-\s]/g, '') === cleanDni) || users[0] || null;
    }
    
    // If still not found, create new client
    let isNewClient = false;
    if (!user) {
      if (!firstName || !lastName) {
        throw new AppError(400, 'Para crear un nuevo cliente se requieren nombre y apellido');
      }
      
      // Generate a temporary email if not provided
      const tempEmail = email || `${cleanDni}@cliente.temp`;
      
      user = await prisma.user.create({
        data: {
          dni: cleanDni,
          firstName,
          lastName,
          email: tempEmail,
          phone: phone || null,
          birthDate: birthDate ? new Date(birthDate) : null,
          role: 'CLIENTE',
          passwordHash: '', // Will be set if client creates account later
        },
        include: { clientProfile: true },
      });
      
      // Create client profile
      await prisma.clientProfile.create({
        data: { userId: user.id },
      });
      
      // Reload user with profile
      user = await prisma.user.findUnique({
        where: { id: user.id },
        include: { clientProfile: true },
      });
      
      isNewClient = true;
    }
    
    // At this point user is guaranteed to exist (either found or created)
    const clientUser = user!;
    
    if (!clientUser.clientProfile) {
      throw new AppError(400, 'Perfil de cliente no encontrado');
    }
    
    // Get default branch (first active branch)
    const defaultBranch = await prisma.branch.findFirst({ where: { isActive: true } });
    if (!defaultBranch) {
      throw new AppError(400, 'No hay sucursales activas');
    }
    
    // Use PurchaseService which handles promotions, coupons, challenges, etc.
    const purchase = await PurchaseService.createPurchase({
      clientId: clientUser.id,
      branchId: defaultBranch.id,
      cashierId: req.user!.id,
      items: items.map((item: any) => ({
        productId: item.productId,
        quantity: item.quantity || 1,
        unitPrice: 0, // Will be fetched from product
        discount: 0,
      })),
      notes,
    });
    
    // Send notifications if points earned
    if (purchase.pointsEarned > 0 && clientUser.email && !clientUser.email.endsWith('@cliente.temp')) {
      await emailService.sendPointsEarnedEmail(clientUser.email, clientUser.firstName, purchase.pointsEarned, purchase.pointsBalance);
    }
    if (purchase.pointsEarned > 0 && clientUser.phone) {
      await whatsappService.sendPointsEarnedNotification(clientUser.phone, clientUser.firstName, purchase.pointsEarned, purchase.pointsBalance);
    }
    
    res.status(201).json({
      transaction: {
        id: purchase.id,
        receiptNumber: purchase.receiptNumber,
        total: purchase.total,
        pointsEarned: purchase.pointsEarned,
        pointsBalance: purchase.pointsBalance,
        createdAt: purchase.createdAt,
      },
      client: {
        currentPoints: purchase.pointsBalance,
        isNewClient,
        firstName: clientUser.firstName,
        lastName: clientUser.lastName,
        dni: clientUser.dni,
      },
      appliedPromotions: purchase.appliedPromotions,
      appliedCoupon: purchase.appliedCoupon,
    });
  } catch (error) {
    next(error);
  }
};

export const getClientHistory = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { dni } = req.params;
    const { page = 1, limit = 20, type } = req.query;
    
    // Clean DNI - remove dots, dashes, spaces
    const cleanDni = dni.replace(/[.\-\s]/g, '');
    
    // Try exact match first
    let user = await prisma.user.findUnique({ where: { dni: cleanDni } });
    
    // If not found, try finding by contains in BOTH directions
    if (!user) {
      const users = await prisma.user.findMany({
        where: {
          role: 'CLIENTE',
        },
      });
      
      user = users.find(u => u.dni.replace(/[.\-\s]/g, '') === cleanDni)
        || users.find(u => u.dni.replace(/[.\-\s]/g, '').includes(cleanDni))
        || users.find(u => cleanDni.includes(u.dni.replace(/[.\-\s]/g, '')))
        || null;
    }
    
    if (!user) throw new AppError(404, 'Cliente no encontrado');
    
    const where: Prisma.TransactionWhereInput = { userId: user.id };
    if (type) where.type = type as TransactionType;
    
    const [transactions, total] = await Promise.all([
      prisma.transaction.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (Number(page) - 1) * Number(limit),
        take: Number(limit),
        include: { items: { include: { product: true } } },
      }),
      prisma.transaction.count({ where }),
    ]);
    
    res.json({
      transactions: transactions.map(t => ({
        id: t.id,
        type: t.type,
        total: Number(t.total),
        pointsEarned: t.pointsEarned,
        pointsBalance: t.pointsBalance,
        description: t.description,
        createdAt: t.createdAt,
        items: t.items.map(i => ({
          productName: i.product.name,
          quantity: i.quantity,
          unitPrice: Number(i.unitPrice),
          lineTotal: Number(i.lineTotal),
        })),
      })),
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    next(error);
  }
};

export const registerQuickPurchase = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { dni, amount, notes, firstName, lastName, email, phone, birthDate } = req.body;
    
    // Clean DNI - remove dots, dashes, spaces
    const cleanDni = dni.replace(/[.\-\s]/g, '');
    
    // Try exact match first
    let user = await prisma.user.findUnique({
      where: { dni: cleanDni },
      include: { clientProfile: true },
    });
    
    // If not found, try finding by contains in BOTH directions
    if (!user) {
      const users = await prisma.user.findMany({
        where: {
          role: 'CLIENTE',
        },
        include: { clientProfile: true },
      });
      
      user = users.find(u => u.dni.replace(/[.\-\s]/g, '') === cleanDni)
        || users.find(u => u.dni.replace(/[.\-\s]/g, '').includes(cleanDni))
        || users.find(u => cleanDni.includes(u.dni.replace(/[.\-\s]/g, '')))
        || null;
    }
    
    // If still not found, create new client
    let isNewClient = false;
    if (!user) {
      if (!firstName || !lastName) {
        throw new AppError(400, 'Para crear un nuevo cliente se requieren nombre y apellido');
      }
      
      // Generate a temporary email if not provided
      const tempEmail = email || `${cleanDni}@cliente.temp`;
      
      user = await prisma.user.create({
        data: {
          dni: cleanDni,
          firstName,
          lastName,
          email: tempEmail,
          phone: phone || null,
          birthDate: birthDate ? new Date(birthDate) : null,
          role: 'CLIENTE',
          passwordHash: '',
        },
        include: { clientProfile: true },
      });
      
      // Create client profile
      await prisma.clientProfile.create({
        data: { userId: user.id },
      });
      
      // Reload user with profile
      user = await prisma.user.findUnique({
        where: { id: user.id },
        include: { clientProfile: true },
      });
      
      isNewClient = true;
    }
    
    // At this point user is guaranteed to exist (either found or created)
    const clientUser = user!;
    
    if (!clientUser.isActive) {
      throw new AppError(403, 'Cliente inactivo');
    }
    
    if (!clientUser.clientProfile) {
      throw new AppError(400, 'Perfil de cliente no encontrado');
    }
    
    // Use PurchaseService for quick purchase with a default product
    // For quick purchase, we create a generic item
    const defaultBranch = await prisma.branch.findFirst({ where: { isActive: true } });
    if (!defaultBranch) {
      throw new AppError(400, 'No hay sucursales activas');
    }
    
    // Create or update generic product for quick purchase (atomic upsert)
    const quickProduct = await prisma.product.upsert({
      where: { code: 'QUICK_PURCHASE' },
      update: { unitPrice: amount / 1.21 },
      create: {
        code: 'QUICK_PURCHASE',
        name: 'Compra Rápida',
        category: 'Varios',
        unitPrice: amount / 1.21,
        isActive: true,
      },
    });
    
    const purchase = await PurchaseService.createPurchase({
      clientId: clientUser.id,
      branchId: defaultBranch.id,
      cashierId: req.user!.id,
      items: [{
        productId: quickProduct.id,
        quantity: 1,
        unitPrice: amount / 1.21,
        discount: 0,
      }],
      notes: notes || 'Compra rápida',
    });
    
    // Send notifications if points earned
    if (purchase.pointsEarned > 0 && clientUser.email && !clientUser.email.endsWith('@cliente.temp')) {
      await emailService.sendPointsEarnedEmail(clientUser.email, clientUser.firstName, purchase.pointsEarned, purchase.pointsBalance);
    }
    if (purchase.pointsEarned > 0 && clientUser.phone) {
      await whatsappService.sendPointsEarnedNotification(clientUser.phone, clientUser.firstName, purchase.pointsEarned, purchase.pointsBalance);
    }
    
    res.status(201).json({
      transaction: {
        id: purchase.id,
        receiptNumber: purchase.receiptNumber,
        total: purchase.total,
        pointsEarned: purchase.pointsEarned,
        pointsBalance: purchase.pointsBalance,
        createdAt: purchase.createdAt,
      },
      client: {
        currentPoints: purchase.pointsBalance,
        isNewClient,
        firstName: clientUser.firstName,
        lastName: clientUser.lastName,
        dni: clientUser.dni,
      },
      appliedPromotions: purchase.appliedPromotions,
      appliedCoupon: purchase.appliedCoupon,
    });
  } catch (error) {
    next(error);
  }
};

export const getClientPoints = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { dni } = req.params;
    
    // Clean DNI - remove dots, dashes, spaces
    const cleanDni = dni.replace(/[.\-\s]/g, '');
    
    // Try exact match first
    let user = await prisma.user.findUnique({
      where: { dni: cleanDni },
      include: { clientProfile: true },
    });
    
    // If not found, try finding by contains in BOTH directions
    if (!user) {
      const users = await prisma.user.findMany({
        where: {
          role: 'CLIENTE',
        },
        include: { clientProfile: true },
      });
      
      user = users.find(u => u.dni.replace(/[.\-\s]/g, '') === cleanDni)
        || users.find(u => u.dni.replace(/[.\-\s]/g, '').includes(cleanDni))
        || users.find(u => cleanDni.includes(u.dni.replace(/[.\-\s]/g, '')))
        || null;
    }
    
    if (!user) throw new AppError(404, 'Cliente no encontrado');
    
    res.json({
      dni: user.dni,
      firstName: user.firstName,
      lastName: user.lastName,
      currentPoints: user.clientProfile?.currentPoints || 0,
      totalPointsEarned: user.clientProfile?.totalPointsEarned || 0,
      totalPointsRedeemed: user.clientProfile?.totalPointsRedeemed || 0,
      tier: user.clientProfile?.tier || 'BRONZE',
    });
  } catch (error) {
    next(error);
  }
};

export const getPendingTierChanges = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const where: any = { pendingTier: { not: null } };
    
    const [clients, total] = await Promise.all([
      prisma.user.findMany({
        where,
        include: { clientProfile: true },
        orderBy: { updatedAt: 'desc' },
        skip: (Number(page) - 1) * Number(limit),
        take: Number(limit),
      }),
      prisma.user.count({ where }),
    ]);

    res.json({
      clients: clients.map(u => ({
        id: u.id,
        firstName: u.firstName,
        lastName: u.lastName,
        dni: u.dni,
        email: u.email,
        phone: u.phone,
        currentTier: u.clientProfile?.tier || 'BRONZE',
        pendingTier: u.clientProfile?.pendingTier,
        totalPointsEarned: u.clientProfile?.totalPointsEarned || 0,
        currentPoints: u.clientProfile?.currentPoints || 0,
        updatedAt: u.updatedAt,
      })),
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    next(error);
  }
};

export const approveTierChange = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const { approved } = req.body;

    const user = await prisma.user.findUnique({
      where: { id },
      include: { clientProfile: true },
    });

    if (!user) throw new AppError(404, 'Cliente no encontrado');
    if (!user.clientProfile?.pendingTier) throw new AppError(400, 'No hay cambio de tier pendiente');

    const newTier = approved ? user.clientProfile.pendingTier : user.clientProfile.tier;

    await prisma.clientProfile.update({
      where: { userId: user.id },
      data: {
        tier: newTier,
        pendingTier: null,
      },
    });

    // Registrar en el log de cambios de tier
    await (prisma as any).tierChangeLog.create({
      data: {
        userId: user.id,
        fromTier: user.clientProfile.tier,
        toTier: newTier,
        approved,
        approvedBy: req.user!.id,
        approvedAt: new Date(),
      },
    });

    // Notificar al cliente
    if (user.email) {
      const message = approved 
        ? `¡Felicitaciones! Tu solicitud de cambio a ${newTier} ha sido APROBADA.`
        : `Tu solicitud de cambio a ${user.clientProfile.pendingTier} ha sido RECHAZADA. Mantienes tu tier actual: ${user.clientProfile.tier}.`;
      
      // await emailService.sendTierChangeEmail(user.email, user.firstName, approved, newTier, user.clientProfile.tier);
      await prisma.notification.create({
        data: {
          userId: user.id,
          type: 'TIER_CHANGE',
          title: approved ? 'Cambio de Nivel Aprobado' : 'Cambio de Nivel Rechazado',
          message,
          metadata: { newTier, previousTier: user.clientProfile.tier },
        },
      });
    }

    res.json({ 
      message: approved ? 'Cambio de tier aprobado' : 'Cambio de tier rechazado',
      tier: newTier 
    });
  } catch (error) {
    next(error);
  }
};

export const getClientTierHistory = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const history = await (prisma as any).tierChangeLog.findMany({
      where: { userId: id },
      orderBy: { createdAt: 'desc' },
    });
    res.json({ history });
  } catch (error) {
    next(error);
  }
};