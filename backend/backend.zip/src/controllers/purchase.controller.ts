import { Request, Response, NextFunction } from 'express';
import { PurchaseService } from '../services/purchase.service';
import { AppError } from '../middleware/errorHandler';
import { AuthRequest } from '../middleware/auth';
import { PurchaseStatus, Prisma } from '@prisma/client';

export const createPurchase = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { clientId, branchId, items, couponCode, notes } = req.body;
    const cashierId = req.user!.id;

    if (!clientId || !branchId || !items || !Array.isArray(items) || items.length === 0) {
      throw new AppError(400, 'Datos de compra incompletos');
    }

    const purchase = await PurchaseService.createPurchase({
      clientId,
      branchId,
      cashierId,
      items,
      couponCode: req.body.couponCode,
      notes: req.body.notes,
    });

    res.status(201).json(purchase);
  } catch (error) {
    next(error);
  }
};

export const getPurchaseById = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const purchase = await PurchaseService.getPurchaseById(id);
    if (!purchase) throw new AppError(404, 'Compra no encontrada');
    res.json(purchase);
  } catch (error) {
    next(error);
  }
};

export const getPurchases = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { page = 1, limit = 20, clientId, branchId, startDate, endDate, status } = req.query;

    const filters: any = {};
    if (clientId) filters.clientId = clientId as string;
    if (branchId) filters.branchId = branchId as string;
    if (status) filters.status = status as string;
    if (startDate) filters.startDate = new Date(startDate as string);
    if (endDate) filters.endDate = new Date(endDate as string);
    if (page) filters.page = Number(page);
    if (limit) filters.limit = Number(limit);

    const result = await PurchaseService.getPurchases(filters);
    res.json(result);
  } catch (error) {
    next(error);
  }
};

export const cancelPurchase = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    await PurchaseService.cancelPurchase(id);
    res.json({ message: 'Compra cancelada correctamente' });
  } catch (error) {
    next(error);
  }
};