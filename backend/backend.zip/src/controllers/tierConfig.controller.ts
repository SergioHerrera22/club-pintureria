import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/prisma';
import { AppError } from '../middleware/errorHandler';
import { AuthRequest } from '../middleware/auth';
import { Prisma } from '@prisma/client';

export const getTierConfigs = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { isActive } = req.query;
    
    const where: Prisma.TierConfigWhereInput = {};
    if (isActive !== undefined) where.isActive = isActive === 'true';
    
    const tiers = await prisma.tierConfig.findMany({
      where,
      orderBy: [{ sortOrder: 'asc' }, { minPoints: 'asc' }],
    });
    
    res.json({ tiers });
  } catch (error) {
    next(error);
  }
};

export const getTierConfigById = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const tier = await prisma.tierConfig.findUnique({ where: { id } });
    if (!tier) throw new AppError(404, 'Tier no encontrado');
    res.json(tier);
  } catch (error) {
    next(error);
  }
};

export const createTierConfig = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { name, label, minPoints, maxPoints, color, pointsMultiplier, pointsExpiryDays, birthdayBonusPoints, isActive, sortOrder } = req.body;
    
    const existing = await prisma.tierConfig.findUnique({ where: { name } });
    if (existing) throw new AppError(409, 'Nombre de tier ya existe');
    
    const tier = await prisma.tierConfig.create({
      data: {
        name,
        label,
        minPoints: minPoints || 0,
        maxPoints: maxPoints || null,
        color: color || '#6B7280',
        pointsMultiplier: pointsMultiplier || 1.0,
        pointsExpiryDays: pointsExpiryDays || null,
        birthdayBonusPoints: birthdayBonusPoints || 0,
        isActive: isActive !== undefined ? isActive : true,
        sortOrder: sortOrder || 0,
      },
    });
    
    res.status(201).json(tier);
  } catch (error) {
    next(error);
  }
};

export const updateTierConfig = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const { name, label, minPoints, maxPoints, color, pointsMultiplier, pointsExpiryDays, birthdayBonusPoints, isActive, sortOrder } = req.body;
    
    const data: Record<string, unknown> = {};
    if (name !== undefined) data.name = name;
    if (label !== undefined) data.label = label;
    if (minPoints !== undefined) data.minPoints = minPoints;
    if (maxPoints !== undefined) data.maxPoints = maxPoints === null ? null : maxPoints;
    if (color !== undefined) data.color = color;
    if (pointsMultiplier !== undefined) data.pointsMultiplier = pointsMultiplier;
    if (pointsExpiryDays !== undefined) data.pointsExpiryDays = pointsExpiryDays === null ? null : pointsExpiryDays;
    if (birthdayBonusPoints !== undefined) data.birthdayBonusPoints = birthdayBonusPoints;
    if (isActive !== undefined) data.isActive = isActive;
    if (sortOrder !== undefined) data.sortOrder = sortOrder;
    
    const tier = await prisma.tierConfig.update({
      where: { id },
      data,
    });
    
    res.json(tier);
  } catch (error) {
    next(error);
  }
};

export const deleteTierConfig = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    await prisma.tierConfig.delete({ where: { id } });
    res.json({ message: 'Tier eliminado' });
  } catch (error) {
    next(error);
  }
};

export const initializeDefaultTiers = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const existingCount = await prisma.tierConfig.count();
    if (existingCount > 0) {
      throw new AppError(400, 'Ya existen tiers configurados. Elimínelos primero si desea reinicializar.');
    }
    
    const defaultTiers = [
      { name: 'BRONZE', label: 'Bronce', minPoints: 0, maxPoints: 999, color: '#CD7F32', pointsMultiplier: 1.0, pointsExpiryDays: 365, birthdayBonusPoints: 0, isActive: true, sortOrder: 1 },
      { name: 'SILVER', label: 'Plata', minPoints: 1000, maxPoints: 4999, color: '#C0C0C0', pointsMultiplier: 1.25, pointsExpiryDays: 365, birthdayBonusPoints: 100, isActive: true, sortOrder: 2 },
      { name: 'GOLD', label: 'Oro', minPoints: 5000, maxPoints: 19999, color: '#FFD700', pointsMultiplier: 1.5, pointsExpiryDays: 365, birthdayBonusPoints: 250, isActive: true, sortOrder: 3 },
      { name: 'PLATINUM', label: 'Platino', minPoints: 20000, maxPoints: null, color: '#E5E4E2', pointsMultiplier: 2.0, pointsExpiryDays: null, birthdayBonusPoints: 500, isActive: true, sortOrder: 4 },
    ];
    
    await prisma.tierConfig.createMany({ data: defaultTiers });
    
    const tiers = await prisma.tierConfig.findMany({ orderBy: { sortOrder: 'asc' } });
    res.json({ tiers });
  } catch (error) {
    next(error);
  }
};

export const getClientTier = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { dni } = req.params;
    
    const user = await prisma.user.findUnique({
      where: { dni },
      include: { clientProfile: true },
    });
    
    if (!user) throw new AppError(404, 'Cliente no encontrado');
    if (!user.clientProfile) throw new AppError(400, 'Perfil de cliente no encontrado');
    
    const tier = await prisma.tierConfig.findUnique({
      where: { name: user.clientProfile.tier },
    });
    
    const currentPoints = user.clientProfile.currentPoints;
    const nextTier = await prisma.tierConfig.findFirst({
      where: { minPoints: { gt: currentPoints }, isActive: true },
      orderBy: { minPoints: 'asc' },
    });
    
    res.json({
      currentTier: tier || { name: user.clientProfile.tier, label: user.clientProfile.tier, pointsMultiplier: 1.0 },
      currentPoints,
      nextTier: nextTier ? { name: nextTier.name, label: nextTier.label, minPoints: nextTier.minPoints, pointsNeeded: nextTier.minPoints - currentPoints } : null,
    });
  } catch (error) {
    next(error);
  }
};